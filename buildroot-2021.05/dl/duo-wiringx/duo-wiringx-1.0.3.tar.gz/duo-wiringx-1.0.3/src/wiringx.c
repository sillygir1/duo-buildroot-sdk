/*
	Copyright (c) 2016 CurlyMo <curlymoo1@gmail.com>

  This Source Code Form is subject to the terms of the Mozilla Public
  License, v. 2.0. If a copy of the MPL was not distributed with this
  file, You can obtain one at http://mozilla.org/MPL/2.0/.
*/

#include <stdio.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <fcntl.h>
#include <termios.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#ifndef __FreeBSD__
	#include <linux/spi/spidev.h>
	#include "i2c-dev.h"
#endif

#include "wiringx.h"

#include "soc/allwinner/a10.h"
#include "soc/allwinner/a31s.h"
#include "soc/allwinner/h3.h"
#include "soc/allwinner/h5.h"
#include "soc/nxp/imx6dqrm.h"
#include "soc/nxp/imx6sdlrm.h"
#include "soc/broadcom/2835.h"
#include "soc/broadcom/2836.h"
#include "soc/broadcom/2711.h"
#include "soc/amlogic/s805.h"
#include "soc/amlogic/s905.h"
#include "soc/samsung/exynos5422.h"
#include "soc/rockchip/rk3399.h"
#include "soc/rockchip/rk3588.h"
#include "soc/sophgo/cv180x.h"
#include "soc/sophgo/sg2002.h"
#include "soc/sophgo/sg2000.h"

#include "platform/linksprite/pcduino1.h"
#include "platform/lemaker/bananapi1.h"
#include "platform/lemaker/bananapim2.h"
#include "platform/xunlong/orangepipc+.h"
#include "platform/xunlong/orangepipc2.h"
#include "platform/solidrun/hummingboard_gate_edge_sdl.h"
#include "platform/solidrun/hummingboard_gate_edge_dq.h"
#include "platform/solidrun/hummingboard_base_pro_sdl.h"
#include "platform/solidrun/hummingboard_base_pro_dq.h"
#include "platform/raspberrypi/raspberrypi1b1.h"
#include "platform/raspberrypi/raspberrypi1b2.h"
#include "platform/raspberrypi/raspberrypi1b+.h"
#include "platform/raspberrypi/raspberrypizero.h"
#include "platform/raspberrypi/raspberrypi2.h"
#include "platform/raspberrypi/raspberrypi3.h"
#include "platform/raspberrypi/raspberrypi4.h"
#include "platform/hardkernel/odroidc1.h"
#include "platform/hardkernel/odroidc2.h"
#include "platform/hardkernel/odroidxu4.h"
#include "platform/radxa/rock4.h"
#include "platform/radxa/rock5b.h"
#include "platform/milkv/duo.h"
#include "platform/milkv/duo256m.h"
#include "platform/milkv/duos.h"

typedef time_t __time_t;
typedef suseconds_t __suseconds_t;

void wiringXDefaultLog(int prio, char *file, int line, const char *format_str, ...);

static struct platform_t *platform = NULL;
static int namenr = 0;
void (*_wiringXLog)(int, char *, int, const char *, ...) = wiringXDefaultLog;

static int issetup = 0;
static int isinit = 0;

#ifndef __FreeBSD__
/* SPI Bus Parameters */

struct spi_t {
	uint8_t mode;
	uint8_t bits_per_word;
	uint16_t delay;
	uint32_t speed;
	int fd;
} spi_t;

static struct spi_t spi[2] = {
	{ 0, 0, 0, 0, 0 },
	{ 0, 0, 0, 0, 0 }
};
#endif

#ifdef _WIN32
#define timeradd(a, b, result) \
	do { \
		(result)->tv_sec = (a)->tv_sec + (b)->tv_sec; \
		(result)->tv_usec = (a)->tv_usec + (b)->tv_usec; \
		if ((result)->tv_usec >= 1000000L) { \
			++(result)->tv_sec; \
			(result)->tv_usec -= 1000000L; \
		} \
	} while(0)

#define timersub(a, b, result) \
	do { \
		(result)->tv_sec = (a)->tv_sec - (b)->tv_sec; \
		(result)->tv_usec = (a)->tv_usec - (b)->tv_usec; \
		if ((result)->tv_usec < 0) { \
			--(result)->tv_sec; \
			(result)->tv_usec += 1000000L; \
		} \
	} while(0)
#endif

/* Both the delayMicroseconds and the delayMicrosecondsHard
   are taken from wiringPi */
static void delayMicrosecondsHard(unsigned int howLong) {
	struct timeval tNow, tLong, tEnd ;

	gettimeofday(&tNow, NULL);
#ifdef _WIN32
	tLong.tv_sec  = howLong / 1000000;
	tLong.tv_usec = howLong % 1000000;
#else
	tLong.tv_sec  = (__time_t)howLong / 1000000;
	tLong.tv_usec = (__suseconds_t)howLong % 1000000;
#endif
	timeradd(&tNow, &tLong, &tEnd);

	while(timercmp(&tNow, &tEnd, <)) {
		gettimeofday(&tNow, NULL);
	}
}

EXPORT void delayMicroseconds(unsigned int howLong) {
	struct timespec sleeper;
#ifdef _WIN32
	long int uSecs = howLong % 1000000;
	unsigned int wSecs = howLong / 1000000;
#else
	long int uSecs = (__time_t)howLong % 1000000;
	unsigned int wSecs = howLong / 1000000;
#endif

	if(howLong == 0) {
		return;
	} else if(howLong  < 100) {
		delayMicrosecondsHard(howLong);
	} else {
#ifdef _WIN32
		sleeper.tv_sec = wSecs;
#else
		sleeper.tv_sec = (__time_t)wSecs;
#endif
		sleeper.tv_nsec = (long)(uSecs * 1000L);
		nanosleep(&sleeper, NULL);
	}
}

void wiringXDefaultLog(int prio, char *file, int line, const char *format_str, ...) {
	va_list ap, apcpy;
	char buf[64], *l = malloc(128);
	int save_errno = -1, pos = 0, bytes = 0;

	if(l == NULL) {
		fprintf(stderr, "out of memory\n");
		exit(-1);
	}

	save_errno = errno;

	memset(l, '\0', 128);
	memset(buf, '\0',  64);

	switch(prio) {
		case LOG_WARNING:
			pos += sprintf(l, "WARNING: ");
		break;
		case LOG_ERR:
			pos += sprintf(l, "ERROR: ");
		break;
		case LOG_INFO:
			pos += sprintf(l, "INFO: ");
		break;
		case LOG_NOTICE:
			pos += sprintf(l, "NOTICE: ");
		break;
		case LOG_DEBUG:
			pos += sprintf(l, "DEBUG: ");
		break;
		default:
		break;
	}

	va_copy(apcpy, ap);
	va_start(apcpy, format_str);
#ifdef _WIN32
	bytes = _vscprintf(format_str, apcpy);
#else
	bytes = vsnprintf(NULL, 0, format_str, apcpy);
#endif
	if(bytes == -1) {
		fprintf(stderr, "ERROR: unproperly formatted wiringX log message %s\n", format_str);
	} else {
		va_end(apcpy);
		if((l = realloc(l, (size_t)bytes+(size_t)pos+3)) == NULL) {
			fprintf(stderr, "out of memory\n");
			exit(-1);
		}
		va_start(ap, format_str);
		pos += vsprintf(&l[pos], format_str, ap);
		va_end(ap);
	}
	l[pos++]='\n';
	l[pos++]='\0';

	fprintf(stderr, "%s", l);

	free(l);
	errno = save_errno;
}

static void wiringXInit(void) {
	if(isinit == 0) {
		isinit = 1;
	} else {
		return;
	}

	/* Init all SoC's */
	allwinnerA10Init();
	allwinnerA31sInit();
	allwinnerH3Init();
	allwinnerH5Init();
	nxpIMX6DQRMInit();
	nxpIMX6SDLRMInit();
	broadcom2835Init();
	broadcom2836Init();
	broadcom2711Init();
	amlogicS805Init();
	amlogicS905Init();
	exynos5422Init();
	rk3399Init();
	rk3588Init();
	cv180xInit();
	sg2002Init();
	sg2000Init();

	/* Init all platforms */
	pcduino1Init();
	bananapi1Init();
	bananapiM2Init();
	orangepipcpInit();
	orangepipc2Init();
	hummingboardBaseProSDLInit();
	hummingboardBaseProDQInit();
	hummingboardGateEdgeSDLInit();
	hummingboardGateEdgeDQInit();
	raspberrypi1b1Init();
	raspberrypi1b2Init();
	raspberrypi1bpInit();
	raspberrypizeroInit();
	raspberrypi2Init();
	raspberrypi3Init();
	raspberrypi4Init();
	odroidc1Init();
	odroidc2Init();
	odroidxu4Init();
	rock4Init();
	rock5bInit();
	milkv_duoInit();
	milkv_duo256mInit();
	milkv_duosInit();
}

EXPORT int wiringXSetup(char *name, void (*func)(int, char *, int, const char *, ...)) {
	if(issetup == 0) {
		issetup = 1;
	} else {
		return 0;
	}

	if(func != NULL) {
		_wiringXLog = func;
	} else {
		_wiringXLog = wiringXDefaultLog;
	}

	wiringXInit();

	if(name != NULL) {
		if((platform = platform_get_by_name(name, &namenr)) == NULL) {
			char *tmp = NULL;
			char message[1024];
			int l = 0;
			l = snprintf(message, 1023-l, "The %s is an unsupported or unknown platform\n", name);
			l += snprintf(&message[l], 1023-l, "\tsupported wiringX platforms are:\n");
			int i = 0;
			while((tmp = platform_iterate_name(i++)) != NULL) {
				l += snprintf(&message[l], 1023-l, "\t- %s\n", tmp);
			}
			wiringXLog(LOG_ERR, message);
			return -1;
		}
		platform->setup();
	}

	return 0;
}

EXPORT char *wiringXPlatform(void) {
	if(platform == NULL) {
		wiringXLog(LOG_ERR, "wiringX has not been properly setup (no platform has been selected)");
		return NULL;
	}
	return platform->name[namenr];
}

EXPORT int pinMode(int pin, enum pinmode_t mode) {
	if(platform == NULL) {
		wiringXLog(LOG_ERR, "wiringX has not been properly setup (no platform has been selected)");
		return -1;
	} else if(platform->pinMode == NULL) {
		wiringXLog(LOG_ERR, "The %s does not support the pinMode functionality", platform->name[namenr]);
		return -1;
	}
	return platform->pinMode(pin, mode);
}

EXPORT int digitalWrite(int pin, enum digital_value_t value) {
	if(platform == NULL) {
		wiringXLog(LOG_ERR, "wiringX has not been properly setup (no platform has been selected)");
		return -1;
	}	else if(platform->digitalWrite == NULL) {
		wiringXLog(LOG_ERR, "The %s does not support the digitalWrite functionality", platform->name[namenr]);
		return -1;
	}
	return platform->digitalWrite(pin, value);
}

EXPORT int digitalRead(int pin) {
	if(platform == NULL) {
		wiringXLog(LOG_ERR, "wiringX has not been properly setup (no platform has been selected)");
		return -1;
	}	else if(platform->digitalRead == NULL) {
		wiringXLog(LOG_ERR, "The %s does not support the digitalRead functionality", platform->name[namenr]);
		return -1;
	}
	return platform->digitalRead(pin);
}

EXPORT int wiringXISR(int pin, enum isr_mode_t mode) {
	if(platform == NULL) {
		wiringXLog(LOG_ERR, "wiringX has not been properly setup (no platform has been selected)");
		return -1;
	}	else if(platform->isr == NULL) {
		wiringXLog(LOG_ERR, "The %s does not support the wiringXISR functionality", platform->name[namenr]);
		return -1;
	}
	return platform->isr(pin, mode);
}

EXPORT int waitForInterrupt(int pin, int ms) {
	if(platform == NULL) {
		wiringXLog(LOG_ERR, "wiringX has not been properly setup (no platform has been selected)");
		return -1;
	}	else if(platform->waitForInterrupt == NULL) {
		wiringXLog(LOG_ERR, "The %s does not support the waitForInterrupt functionality", platform->name[namenr]);
		return -1;
	}
	return platform->waitForInterrupt(pin, ms);
}

EXPORT int wiringXValidGPIO(int pin) {
	if(platform == NULL) {
		wiringXLog(LOG_ERR, "wiringX has not been properly setup (no platform has been selected)");
		return -1;
	}	else if(platform->validGPIO == NULL) {
		wiringXLog(LOG_ERR, "The %s does not support the wiringXValidGPIO functionality", platform->name[namenr]);
		return -1;
	}
	return platform->validGPIO(pin);
}

#ifndef __FreeBSD__
EXPORT int wiringXI2CRead(int fd) {
	return i2c_smbus_read_byte(fd);
}

EXPORT int wiringXI2CReadReg8(int fd, int reg) {
	return i2c_smbus_read_byte_data(fd, reg);
}

EXPORT int wiringXI2CReadReg16(int fd, int reg) {
	return i2c_smbus_read_word_data(fd, reg);
}

EXPORT int wiringXI2CReadBlockData(int fd, int reg, unsigned char *block, int block_size) {
	return i2c_smbus_read_data_block(fd, reg, block, block_size);
}

EXPORT int wiringXI2CWrite(int fd, int data) {
	return i2c_smbus_write_byte(fd, data);
}

EXPORT int wiringXI2CWriteReg8(int fd, int reg, int data) {
	return i2c_smbus_write_byte_data(fd, reg, data);
}

EXPORT int wiringXI2CWriteReg16(int fd, int reg, int data) {
	return i2c_smbus_write_word_data(fd, reg, data);
}

EXPORT int wiringXI2CWriteBlockData(int fd, int reg, unsigned char *block, int block_size) {
	return i2c_smbus_write_data_block(fd, reg, block, block_size);
}

EXPORT int wiringXI2CWriteBlockDataWithSize(int fd, int reg, unsigned char *block, int block_size) {
	return i2c_smbus_write_data_block_with_size(fd, reg, block, block_size);
}

EXPORT int wiringXI2CSetup(const char *path, int devId) {
	int fd = 0;

	if((fd = open(path, O_RDWR)) < 0) {
		wiringXLog(LOG_ERR, "wiringX failed to open %s for reading and writing", path);
		return -1;
	}

	if(ioctl(fd, I2C_SLAVE, devId) < 0) {
		wiringXLog(LOG_ERR, "wiringX failed to set %s to slave mode", path);
		return -1;
	}

	return fd;
}

EXPORT int wiringXSPIGetFd(int channel) {
	return spi[channel & 1].fd;
}

EXPORT int wiringXSPIDataRW(int channel, unsigned char *data, int len) {
	struct spi_ioc_transfer tmp;
	memset(&tmp, 0, sizeof(tmp));
	channel &= 1;

	tmp.tx_buf = (uintptr_t)data;
	tmp.rx_buf = (uintptr_t)data;
	tmp.len = len;
	tmp.delay_usecs = spi[channel].delay;
	tmp.speed_hz = spi[channel].speed;
	tmp.bits_per_word = spi[channel].bits_per_word;
#ifdef SPI_IOC_WR_MODE32
	tmp.tx_nbits = 0;
#endif
#ifdef SPI_IOC_RD_MODE32
	tmp.rx_nbits = 0;
#endif

	if(ioctl(spi[channel].fd, SPI_IOC_MESSAGE(1), &tmp) < 0) {
		wiringXLog(LOG_ERR, "wiringX is unable to read/write from channel %d (%s)", channel, strerror(errno));
		return -1;
	}
	return 0;
}

EXPORT int wiringXSPISetup(int channel, int speed) {
	const char *device = NULL;

	channel &= 1;

	if(channel == 0) {
		device = "/dev/spidev0.0";
	} else {
		device = "/dev/spidev0.1";
	}

	if((spi[channel].fd = open(device, O_RDWR)) < 0) {
		wiringXLog(LOG_ERR, "wiringX is unable to open SPI device %s (%s)", device, strerror(errno));
		return -1;
	}

	spi[channel].speed = speed;

	if(ioctl(spi[channel].fd, SPI_IOC_WR_MODE, &spi[channel].mode) < 0) {
		wiringXLog(LOG_ERR, "wiringX is unable to set write mode for device %s (%s)", device, strerror(errno));
		close(spi[channel].fd);
		return -1;
	}

	if(ioctl(spi[channel].fd, SPI_IOC_RD_MODE, &spi[channel].mode) < 0) {
		wiringXLog(LOG_ERR, "wiringX is unable to set read mode for device %s (%s)", device, strerror(errno));
		close(spi[channel].fd);
		return -1;
	}

	if(ioctl(spi[channel].fd, SPI_IOC_WR_BITS_PER_WORD, &spi[channel].bits_per_word) < 0) {
		wiringXLog(LOG_ERR, "wiringX is unable to set write bits_per_word for device %s (%s)", device, strerror(errno));
		close(spi[channel].fd);
		return -1;
	}

	if(ioctl(spi[channel].fd, SPI_IOC_RD_BITS_PER_WORD, &spi[channel].bits_per_word) < 0) {
		wiringXLog(LOG_ERR, "wiringX is unable to set read bits_per_word for device %s (%s)", device, strerror(errno));
		close(spi[channel].fd);
		return -1;
	}

	if(ioctl(spi[channel].fd, SPI_IOC_WR_MAX_SPEED_HZ, &spi[channel].speed) < 0) {
		wiringXLog(LOG_ERR, "wiringX is unable to set write max_speed for device %s (%s)", device, strerror(errno));
		close(spi[channel].fd);
		return -1;
	}

	if(ioctl(spi[channel].fd, SPI_IOC_RD_MAX_SPEED_HZ, &spi[channel].speed) < 0) {
		wiringXLog(LOG_ERR, "wirignX is unable to set read max_speed for device %s (%s)", device, strerror(errno));
		close(spi[channel].fd);
		return -1;
	}

	return spi[channel].fd;
}
#endif

EXPORT int wiringXSerialOpen(const char *device, struct wiringXSerial_t wiringXSerial) {
	struct termios options;
	speed_t myBaud;
	int status = 0, fd = 0;

	switch(wiringXSerial.baud) {
		case 50: myBaud = B50; break;
		case 75: myBaud = B75; break;
		case 110:	myBaud = B110; break;
		case 134:	myBaud = B134; break;
		case 150:	myBaud = B150; break;
		case 200:	myBaud = B200; break;
		case 300:	myBaud = B300; break;
		case 600:	myBaud = B600; break;
		case 1200: myBaud = B1200; break;
		case 1800: myBaud = B1800; break;
		case 2400: myBaud = B2400; break;
		case 4800: myBaud = B4800; break;
		case 9600: myBaud = B9600; break;
		case 19200: myBaud = B19200; break;
		case 38400: myBaud = B38400; break;
		case 57600: myBaud = B57600; break;
		case 115200: myBaud = B115200; break;
		case 230400: myBaud = B230400; break;
		default:
		return -1;
	}

	if((fd = open(device, O_RDWR | O_NOCTTY | O_NDELAY | O_NONBLOCK)) == -1) {
		return -1;
	}

	fcntl(fd, F_SETFL, O_RDWR);

	tcgetattr(fd, &options);

	cfmakeraw(&options);
	cfsetispeed(&options, myBaud);
	cfsetospeed(&options, myBaud);

	options.c_cflag |= (CLOCAL | CREAD);

	options.c_cflag &= ~CSIZE;

	switch(wiringXSerial.databits) {
		case 7:
			options.c_cflag |= CS7;
		break;
		case 8:
			options.c_cflag |= CS8;
		break;
		default:
			wiringXLog(LOG_ERR, "wiringX serial interface can not handle the %d data size", wiringXSerial.databits);
		return -1;
	}
	switch(wiringXSerial.parity) {
		case 'n':
		case 'N':/*no parity*/
			options.c_cflag &= ~PARENB;
			options.c_iflag &= ~INPCK;
		break;
		case 'o':
		case 'O':
			options.c_cflag |= (PARODD | PARENB);
			options.c_iflag |= INPCK; /* Disable parity checking */
		break;
		case 'e':
		case 'E':
			options.c_cflag |= PARENB; /* Enable parity */
			options.c_cflag &= ~PARODD;
			options.c_iflag |= INPCK;
		break;
		case 'S':
		case 's': /*as no parity*/
			options.c_cflag &= ~PARENB;
			options.c_cflag &= ~CSTOPB;
		break;
		default:
			wiringXLog(LOG_ERR, "wiringX serial interface can not handle the %d parity", wiringXSerial.parity);
		return -1;
	}
	switch(wiringXSerial.stopbits) {
		case 1:
			options.c_cflag &= ~CSTOPB;
		break;
		case 2:
			options.c_cflag |= CSTOPB;
		break;
		default:
			wiringXLog(LOG_ERR, "wiringX serial interface can not handle the %d stop bit", wiringXSerial.stopbits);
		return -1;
	}
	switch(wiringXSerial.flowcontrol) {
		case 'x':
		case 'X':
			options.c_iflag |= (IXON | IXOFF | IXANY);
		break;
		case 'n':
		case 'N':
			options.c_iflag &= ~(IXON | IXOFF | IXANY);
		break;
		default:
			wiringXLog(LOG_ERR, "wiringX serial interface can not handle the %d flowcontol", wiringXSerial.flowcontrol);
		return -1;
	}

	options.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);
	options.c_oflag &= ~OPOST;

	options.c_cc[VMIN] = 0;
	options.c_cc[VTIME] = 150;

	tcflush(fd,TCIFLUSH);

	tcsetattr(fd, TCSANOW | TCSAFLUSH, &options);

	ioctl(fd, TIOCMGET, &status);

	status |= TIOCM_DTR;
	status |= TIOCM_RTS;

	ioctl(fd, TIOCMSET, &status);

	return fd;
}

EXPORT void wiringXSerialFlush(int fd) {
	if(fd > 0) {
		tcflush(fd, TCIOFLUSH);
	} else {
		wiringXLog(LOG_ERR, "wiringX serial interface has not been opened");
	}
}

EXPORT void wiringXSerialClose(int fd) {
	if(fd > 0) {
		close(fd);
	}
}

EXPORT void wiringXSerialPutChar(int fd, unsigned char c) {
	if(fd > 0) {
		int x = write(fd, &c, 1);
		if(x != 1) {
			wiringXLog(LOG_ERR, "wiringX failed to write to serial device");
		}
	} else {
		wiringXLog(LOG_ERR, "wiringX serial interface has not been opened");
	}
}

EXPORT void wiringXSerialPuts(int fd, const char *s) {
	if(fd > 0) {
		int x = write(fd, s, strlen(s));
		if(x != strlen(s)) {
			wiringXLog(LOG_ERR, "wiringX failed to write to serial device");
		}
	} else {
		wiringXLog(LOG_ERR, "wiringX serial interface has not been opened");
	}
}

EXPORT void wiringXSerialPrintf(int fd, const char *message, ...) {
	va_list argp;
	char buffer[1024];

	memset(&buffer, '\0', 1024);

	if(fd > 0) {
		va_start(argp, message);
		vsnprintf(buffer, 1023, message, argp);
		va_end(argp);

		wiringXSerialPuts(fd, buffer);
	} else {
		wiringXLog(LOG_ERR, "wiringX serial interface has not been opened");
	}
}

EXPORT int wiringXSerialDataAvail(int fd) {
	int result = 0;

	if(fd > 0) {
		if(ioctl(fd, FIONREAD, &result) == -1) {
			return -1;
		}
		return result;
	} else {
		wiringXLog(LOG_ERR, "wiringX serial interface has not been opened");
		return -1;
	}
}

EXPORT int wiringXSerialGetChar(int fd) {
	uint8_t x = 0;

	if(fd > 0) {
		if(read(fd, &x, 1) != 1) {
			return -1;
		}
		return ((int)x) & 0xFF;
	} else {
		wiringXLog(LOG_ERR, "wiringX serial interface has not been opened");
		return -1;
	}
}

EXPORT int wiringXPWMSetPeriod(int pin, long period) {
	if (platform == NULL) {
		wiringXLog(LOG_ERR, "wiringX has not been properly setup (no platform has been selected)");
		return -1;
	} else if (platform->pwmSetPeriod == NULL) {
		wiringXLog(LOG_ERR, "The %s does not support the pwmSetPeriod functionality", platform->name[namenr]);
		return -1;
	}
	return platform->pwmSetPeriod(pin, period);
}

EXPORT int wiringXPWMSetDuty(int pin, long duty_cycle) {
	if (platform == NULL) {
		wiringXLog(LOG_ERR, "wiringX has not been properly setup (no platform has been selected)");
		return -1;
	} else if (platform->pwmSetDuty == NULL) {
		wiringXLog(LOG_ERR, "The %s does not support the pwmSetDuty functionality", platform->name[namenr]);
		return -1;
	}
	return platform->pwmSetDuty(pin, duty_cycle);
}

EXPORT int wiringXPWMSetPolarity(int pin, int polarity) {
	if (platform == NULL) {
		wiringXLog(LOG_ERR, "wiringX has not been properly setup (no platform has been selected)");
		return -1;
	} else if (platform->pwmSetPolarity == NULL) {
		wiringXLog(LOG_ERR, "The %s does not support the pwmSetPolarity functionality", platform->name[namenr]);
		return -1;
	}
	return platform->pwmSetPolarity(pin, polarity);
}

EXPORT int wiringXPWMEnable(int pin, int enable) {
	if (platform == NULL) {
		wiringXLog(LOG_ERR, "wiringX has not been properly setup (no platform has been selected)");
		return -1;
	} else if (platform->pwmEnable == NULL) {
		wiringXLog(LOG_ERR, "The %s does not support the pwmEnable functionality", platform->name[namenr]);
		return -1;
	}
	return platform->pwmEnable(pin, enable);
}

EXPORT int wiringXSelectableFd(int gpio) {
	if(platform == NULL) {
		wiringXLog(LOG_ERR, "wiringX has not been properly setup (no platform has been selected)");
		return -1;
	}	else if(platform->selectableFd == NULL) {
		wiringXLog(LOG_ERR, "The %s does not support the wiringXSelectableFd functionality", platform->name[namenr]);
		return -1;
	}
	return platform->selectableFd(gpio);
}

EXPORT int wiringXGC(void) {
	if(platform != NULL) {
		platform->gc();
		platform = NULL;
	}
	platform_gc();
	soc_gc();
	issetup = 0;
	isinit = 0;
	return 0;
}

EXPORT int wiringXSupportedPlatforms(char ***out) {
	wiringXInit();
	char *tmp = NULL;
	int i = 0, x = 0;
	while((tmp = platform_iterate_name(i++)) != NULL);

	if((*out = malloc(sizeof(char *)*i)) == NULL) {
		fprintf(stderr, "out of memory\n");
		exit(-1);
	}

	i = 0;
	while((tmp = platform_iterate_name(i++)) != NULL) {
		if(((*out)[i-1] = strdup(tmp)) == NULL) {
			fprintf(stderr, "out of memory\n");
			exit(-1);
		}
	}
	return i-1;
}
